#pragma once
class Animals
{
public:
	Animals();
	Animals(char s[]);
	Animals(char s[], int l);
	~Animals();
	virtual void characteristics();
	virtual void habitat();
};

