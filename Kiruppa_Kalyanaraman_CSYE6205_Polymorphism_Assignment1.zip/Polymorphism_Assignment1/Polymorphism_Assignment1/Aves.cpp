#include "Aves.h"
#include<iostream>
using namespace std;

char aname[10];
int alegs;
//char lives[10];
//char sizeofanimal[5];

Aves::Aves()
{
}


Aves::~Aves()
{
}

Aves::Aves(char s[])
{
	for (int i = 0; i < 10; i++)
	{
		aname[i] = s[i];
	}
	alegs = 0;
}

Aves::Aves(char s[], int l)
{
	for (int i = 0; i < 10; i++)
	{
		aname[i] = s[i];
	}
	alegs = l;
}
void Aves::characteristics()
{
	cout << endl << "In Aves";
	cout << endl << alegs;
	cout << "\t" << aname;
}
void Aves::habitat()
{
	cout << endl << "Air";
}
