#pragma once
#include "Animals.h"
class Mammals: public Animals
{
public:
	Mammals();
	~Mammals();
	Mammals(char s[]);
	Mammals(char s[], int l);
	void characteristics();
	void habitat();
};

