#include<iostream>
#include "Animals.h"
#include "Mammals.h"
#include "Aves.h"
#include "Reptilia.h"
#include <vector>
using namespace std;
int main()
{
	Animals a;
	a.characteristics();
	a.habitat();

	Mammals human("Human");
	Aves sparrow("Sparrow");
	Reptilia turtle("Turtle");

	vector<Animals*> animal;
	animal.push_back(&human);
	animal.push_back(&sparrow);	
	animal.push_back(&turtle);

	for (int i = 0; i < 3; i++)
	{
		animal[i]->characteristics();
		animal[i]->habitat();
	}

	Mammals elephant("Elephant", 4);
	Aves crow("Crow", 2);
	Reptilia tortoise("Tortoise", 4);

	vector<Animals*> animals;
	animals.push_back(&elephant);
	animals.push_back(&crow);
	animals.push_back(&tortoise);

	for (int i = 0; i < 3; i++)
	{
		animals[i]->characteristics();
		animals[i]->habitat();
	}

	char c;
	cin >> c;
	return 0;
}