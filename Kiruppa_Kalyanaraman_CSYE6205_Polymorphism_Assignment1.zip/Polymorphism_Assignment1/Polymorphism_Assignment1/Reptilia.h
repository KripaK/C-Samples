#pragma once
#include "Animals.h"
class Reptilia: public Animals
{
public:
	Reptilia();
	~Reptilia();
	Reptilia(char s[]);
	Reptilia(char s[], int l);
	void characteristics();
	void habitat();
};

