#pragma once
#include "Animals.h"
class Aves: public Animals
{
public:
	Aves();
	~Aves();
	Aves(char s[]);
	Aves(char s[], int l);
	void characteristics();
	void habitat();
};

