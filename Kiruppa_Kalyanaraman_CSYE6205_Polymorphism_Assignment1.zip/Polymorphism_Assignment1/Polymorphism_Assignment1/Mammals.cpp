#include "Mammals.h"
#include<iostream>
using namespace std;

char mname[10];
int mlegs;
//char lives[10];
//char sizeofanimal[5];
Mammals::Mammals()
{
}

Mammals::~Mammals()
{
}

Mammals::Mammals(char s[])
{
	for (int i = 0; i < 10; i++)
	{
		mname[i] = s[i];
	}
	mlegs = 0;
}

Mammals::Mammals(char s[], int l)
{
	for (int i = 0; i < 10; i++)
	{
		mname[i] = s[i];
	}
	mlegs = l;
}
void Mammals::characteristics()
{
	cout << endl << "In Mammals";
	cout << endl << mlegs;
	cout << "\t" << mname;
}
void Mammals::habitat()
{
	cout << endl << "Land";
}