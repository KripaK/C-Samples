#include "Animals.h"
#include<iostream>
using namespace std;

char nameAnimal[10];
int legsAnimal;
char Alives[10];
char Asizeofanimal[5];
Animals::Animals()
{
}

Animals::Animals(char s[])
{
	for (int i = 0; i < 10; i++)
	{
		nameAnimal[i] = s[i];
	}
	legsAnimal = 0;
}

Animals::Animals(char s[], int l)
{
	for (int i = 0; i < 10; i++)
	{
		nameAnimal[i] = s[i];
	}
	legsAnimal = l;
}
Animals::~Animals()
{
}
void Animals::characteristics()
{
	cout << endl << "In Animals";
	cout << endl << legsAnimal;
	cout << "\t" << nameAnimal;
}
void Animals::habitat()
{
	cout << endl << "Can be air, water or land";
}
