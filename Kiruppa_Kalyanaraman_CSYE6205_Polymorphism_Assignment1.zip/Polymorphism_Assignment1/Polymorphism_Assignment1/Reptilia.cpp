#include "Reptilia.h"
#include<iostream>
using namespace std;

char rname[10];
int rlegs;
//char lives[10];
//char sizeofanimal[5];


Reptilia::Reptilia()
{
}


Reptilia::~Reptilia()
{
}

Reptilia::Reptilia(char s[])
{
	for (int i = 0; i < 10; i++)
	{
		rname[i] = s[i];
	}
	rlegs = 0;
}

Reptilia::Reptilia(char s[], int l)
{
	for (int i = 0; i < 10; i++)
	{
		rname[i] = s[i];
	}
	rlegs = l;
}

void Reptilia::characteristics()
{
	cout << endl << "In Reptilia";
	cout << endl << rlegs;
	cout << "\t" << rname;
}
void Reptilia::habitat()
{
	cout << endl <<"Water" ;
}
