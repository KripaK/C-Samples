#pragma once
#include<string>
#include<iostream>
using namespace std;
class Vehicle
{
public:
	string name;
	float price;
	string model;
	Vehicle();
	Vehicle(string name, float price, string model);
	~Vehicle();
};

