#include "stdafx.h"
#include "Vehicle.h"


Vehicle::Vehicle()
{
}

Vehicle::Vehicle(string a, float c, string b)
{
	name = a;
	model = b;
	price = c;
}
Vehicle::~Vehicle()
{
}
