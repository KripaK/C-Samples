#include "stdafx.h"
#include "Car.h"


Car::Car()
{
}

Car::Car(string a, float c, string b)
{
	name = a;
	model = b;
	price = c;
}

Car::~Car()
{
}
