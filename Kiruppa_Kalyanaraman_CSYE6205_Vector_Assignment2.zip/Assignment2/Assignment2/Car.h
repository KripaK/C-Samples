#pragma once
#include "Vehicle.h"
#include<string>
#include<iostream>
using namespace std;
class Car :
	public Vehicle
{
public:
	string name;
	float price;
	string model;
	Car();
	Car(string name, float price, string model);
	~Car();
};

