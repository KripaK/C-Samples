// Assignment2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Person.h"
#include "Student.h"
#include "Vehicle.h"
#include "Car.h"
#include<iostream>
#include<vector>
#include<algorithm>
#include<fstream>

bool mySortFunction(Student* i, Student* j)
{
	return i->age < j->age;
} 
bool mySortFunction2(Car* i, Car* j)
{
	return i->price < j->price;
}
int main()
{
	vector<Student*> person;
	Student s;

	person.push_back(new Student("a", 97, 98, 19));
	person.push_back(new Student("b", 98, 96, 20));
	person.push_back(new Student("c", 99, 94, 18));
	ifstream input("students.csv");
	string line;
	char* delimitor = ",";
	vector<char*> v;
	while (getline(input, line))
	{
		char* a = _strdup(line.c_str());
		//char* chr = strdup(str.c_str());
		v.push_back(a);
		string name = string(strtok(a, delimitor));
		int markA = stoi(string(strtok(NULL, delimitor)));
		int markB = stoi(string(strtok(NULL, delimitor)));
		int age = stoi(string(strtok(NULL, delimitor)));
		person.push_back(new Student(name, markA, markB, age));
	}
	v.push_back('\0');
	input.close();
	cout << endl;
	cout << endl << "----------------------Alphabetical Order-----------------------";
	for (Student * s : person)
	{
		cout << endl;
		cout << endl << s->name << "\t " << s->markA << "\t" << s->markB << "\t" << s->age;

	}

	sort(person.begin(), person.end(), mySortFunction);
	cout << endl;
	cout << endl << "----------------------After Sorted-------------------------";
	for (Student * s : person)
	{
		cout << endl;
		cout << endl << s->name << "\t " << s->markA << "\t" << s->markB << "\t" << s->age;

	}
	//second set of objects
	ifstream inputStream("cars.csv");
	vector<Car*> car;
	while (getline(inputStream, line))
	{
		char* a = _strdup(line.c_str());
		//char* chr = strdup(str.c_str());
		v.push_back(a);
		string name = string(strtok(a, delimitor));
		string model = string(strtok(NULL, delimitor));
		float price = stof(string(strtok(NULL, delimitor)));
		car.push_back(new Car(name, price, model));
	}
	inputStream.close();
	cout << endl;
	cout << endl << "--------------------Alphabetical Order---------------------";
	for (Car *c : car)
	{
		cout << endl;
		cout << endl << (*c).name << " " << (*c).model << " " << (*c).price;
	}

	sort(car.begin(), car.end(), mySortFunction2);
	cout << endl;
	cout << endl << "----------------------After Sorted----------------------";
	for (Car *c : car)
	{
		cout << endl;
		cout << endl << c->name << " " << c->model << " " << c->price;
	}
	cout << endl;
	return 0;
}

