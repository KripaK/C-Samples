#include "stdafx.h"
#include "Student.h"


Student::Student()
{
}

Student::Student(string Name, float a, float b, int ag)
{
	markA = a;
	markB = b;
	name = Name;
	age = ag;
}

Student::~Student()
{
}

float Student::calcGPA()
{
	float total = markA + markB;
	gpa = total / 2;
	return gpa;
}
