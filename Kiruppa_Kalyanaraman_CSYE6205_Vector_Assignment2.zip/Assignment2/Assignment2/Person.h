#pragma once
#include<string>
#include<iostream>
#include<stdio.h>
using namespace std;
class Person
{
public:
	string name;
	int age;
	float gpa;
	Person();
	Person(string n);
	~Person();
	virtual float calcGPA();
};

