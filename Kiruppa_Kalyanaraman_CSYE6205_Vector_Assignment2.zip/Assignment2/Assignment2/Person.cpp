#include "stdafx.h"
#include "Person.h"


Person::Person()
{
}

Person::Person(string n)
{
	name = n;
}
Person::~Person()
{
}
float Person::calcGPA()
{
	cout << gpa;
	return gpa;
}
