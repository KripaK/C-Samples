#pragma once
#include "Person.h"
class Student :
	public Person
{
public:
	string name;
	int age;
	float gpa;
	float markA, markB;
	float calcGPA();
	Student();
	Student(string name, float a, float b, int age);
	~Student();
};

