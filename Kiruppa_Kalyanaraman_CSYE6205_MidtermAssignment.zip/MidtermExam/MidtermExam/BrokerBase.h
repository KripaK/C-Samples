#pragma once
#include<iostream>
#include"Stock.h"
using namespace std;
class Stock;
class BrokerBase
{
public:
	Stock s[3];
	BrokerBase(Stock stock[3]);
	~BrokerBase();
	BrokerBase();
	virtual void sort();
};

