#include "stdafx.h"
#include "Stock.h"


Stock::Stock()
{
}

Stock::Stock(string s, double p, int r, int v)
{
	stockName = s;
	price = p;
	rank = r;
	volume = v;
}


Stock::~Stock()
{
}
