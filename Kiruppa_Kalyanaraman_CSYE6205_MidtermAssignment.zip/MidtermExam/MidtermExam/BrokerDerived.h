#pragma once
#include "BrokerBase.h"
class Stock;
class BrokerDerived :
	public BrokerBase
{
public:
	Stock s[3];
	BrokerDerived(Stock stock[3]);
	BrokerDerived();
	~BrokerDerived();
	void sort();
};

