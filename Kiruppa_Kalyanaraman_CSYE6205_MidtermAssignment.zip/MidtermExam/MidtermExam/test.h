#pragma once
class test
{
public:
	test();
	~test();
};

