#pragma once
#include<iostream>
using namespace std;
class Stock
{
public:
	string stockName;
	double price;
	int rank;
	int volume;
	Stock();
	Stock(string s, double p, int r, int v);
	~Stock();
};

