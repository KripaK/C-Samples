#include "stdafx.h"
#include "test.h"


test::test()
{
}


test::~test()
{
}
