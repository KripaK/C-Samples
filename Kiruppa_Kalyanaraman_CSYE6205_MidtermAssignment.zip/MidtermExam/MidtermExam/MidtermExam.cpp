// MidtermExam.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<map>
#include<iostream>
#include <array>
#include<vector>
#include "Stock.h"
#include "BrokerBase.h"
#include "BrokerDerived.h"
//#include "test.h"
using namespace std;

bool mySortFunction2(Stock* i, Stock* j)
{
	return i->price < j->price;
}

bool mySortFunction(Stock* i, Stock* j)
{
	return i->rank < j->rank;
}
int main()
{

	vector<Stock*> stock;
	// s;

	//stock.push_back(new Stock("Google", 20.0, 3, 1000));
	//stock.push_back(new Stock("Microsoft", 200.0, 2, 10));
	//stock.push_back(new Stock("Apple", 40.0, 1, 100));


	

	Stock stocks[3];
	Stock s1("Google", 20.0, 3, 1000);
	Stock s2("Microsoft", 200.0, 2, 10);
	Stock s3("Apple", 40.0, 1, 100);
	stocks[0] = s1;
	stocks[1] = s2;
	stocks[2] = s3;
	sort(stock.begin(), stock.end(), mySortFunction);
	cout << endl << "Price";
	//for (Stock *s : stock)
	//{
	//	cout << endl;
	//	cout << endl << s->price<<"\t";
	//}
	sort(stock.begin(), stock.end(), mySortFunction2);

	//for (Stock *s : stock)
	//{
	//	cout << endl;
	//	cout << endl << s->rank;
	//}
	BrokerBase base(stocks);

	BrokerDerived derived(stocks);
	base.sort();
	cout << endl << "Rank";
	derived.sort();
	cout << endl;
    return 0;
}


